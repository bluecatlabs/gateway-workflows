# Copyright 2019 BlueCat Networks. All rights reserved.
# -*- coding: utf-8 -*-

type = 'ui'
sub_pages = [
    {
        'name'        : 'aws_page',
        'title'       : u'Discovery & Visibility AWS',
        'endpoint'    : 'aws/aws_endpoint',
        'description' : u'Discovery AWS'
    },
]
